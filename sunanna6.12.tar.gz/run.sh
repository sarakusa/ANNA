#!/bin/bash
export LD_LIBRARY_PATH=$(dirname "$0")
./xmrig -c config.json
